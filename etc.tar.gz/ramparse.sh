#!/bin/bash
VMLINUX_PATH=~/LV5/android/out-mlv5_global_com/target/product/mlv5/obj/KERNEL_OBJ/vmlinux
RAMDUMP_PATH=~/RAMDUMP/ramdump.bin
RAMDUMP_OUT_PATH=~/RAMDUMP/out
RAMDUMP_PARSER_PATH=~/rp/linux-ramdump-parser-v2/ramparse.py
python $RAMDUMP_PARSER_PATH -d -o $RAMDUMP_OUT_PATH -e $RAMDUMP_PATH 0x40000000 0xbfffffff --phys-offset 0x40000000 -a . -v $VMLINUX_PATH --32-bit
