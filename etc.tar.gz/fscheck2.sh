#!/bin/bash
BLKDEV=$1
[ -z "$BLKDEV" ] && exit

#return to image corrupted
cp testcases/bak/* testcases/

vmtouch -e $BLKDEV 2>&1 > /dev/null
vmtouch -e $(which e2fsck) 2>&1 > /dev/null
vmtouch -e -f $(which awk) 2>&1 > /dev/null

BEFORE_IO=($(cat /sys/block/sda/sda2/stat))
BEFORE=$(($(date +%s%N)/1000000))
FS_STATE=`e2fsck -n $BLKDEV 2>&1 | awk 'BEGIN { need_fsck=0; } /check forced/ { need_fsck=1; } END { print need_fsck }'`
if [ "$FS_STATE" != "0" ]; then
	e2fsck -y $BLKDEV 2>&1 > /dev/null || true   
fi
MIDDLE=$(($(date +%s%N)/1000000))
sudo mount $BLKDEV ./tt
AFTER=$(($(date +%s%N)/1000000))
AFTER_IO=($(cat /sys/block/sda/sda2/stat))

sudo umount ./tt

echo $FS_STATE, $((AFTER-BEFORE))ms, mount $((AFTER-MIDDLE))ms, $((AFTER_IO[0]-BEFORE_IO[0])) read requests, $(((AFTER_IO[2]-BEFORE_IO[2])/8)) read bytes, $((AFTER_IO[3]-BEFORE_IO[3])) ticks
