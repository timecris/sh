#!/bin/sh
SRCDIR=~/Z2/android/out-z2_att_us
WORKDIR=~/IMG


rm $WORKDIR/boot_new.img

#Refer to device/lge/betaz/qcom/device/msm8994/BoardConfig.mk
CMDLINE=console=ttyHSL0,115200,n8 androidboot.console=ttyHSL0 user_debug=31 msm_rtb.filter=0x37 ehci-hcd.park=3 lpm_levels.sleep_disabled=1 androidboot.hardware=z2

#Copy original boot.img and dt.img to OUTPUT directory
cp $SRCDIR/target/product/z2/boot.img $WORKDIR
cp $SRCDIR/target/product/z2/dt.img $WORKDIR

cp $SRCDIR/../kernel/arch/arm64/boot/Image $WORKDIR

#$WORKDIR/split_bootimg.pl $WORKDIR/boot.img

$SRCDIR/host/linux-x86/bin/dtbTool -s 2048 -o $WORKDIR/dt.img -p $SRCDIR/../kernel/scripts/dtc/ $SRCDIR/../kernel/arch/arm64/boot/dts/ chmod a+r $SRCDIR/../kernel/arch/arm64/boot/dt.img

$SRCDIR/host/linux-x86/bin/mkbootimg --kernel $WORKDIR/Image --ramdisk $WORKDIR/boot.img-ramdisk.gz --base 0x00000000 --pagesize 4096 --tags_offset 0x01E0000 --ramdisk_offset 0x02000000 --dt $WORKDIR/dt.img  --cmdline "$CMDLINE" --output $WORKDIR/boot_new.img

$SRCDIR/host/linux-x86/bin/mksecbootimg boot $WORKDIR/boot_new.img lock sha2

echo "Creating boot_new.img has finished"
