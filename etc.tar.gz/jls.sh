#!/bin/bash
JOURNAL_INODE=$(fsstat /dev/xvda1 | grep "Journal Inode" | awk '{print $3}')
JOURNAL_START_BLOCK=$(debugfs /dev/xvda1 -R "bmap <$JOURNAL_INODE> 0")
JOURNAL_LENGTH=$(dumpe2fs /dev/xvda1 | grep "Journal length" | awk '{print $3}')

blocknr="$1"
journal_block_nr=$((blocknr-JOURNAL_START_BLOCK))
jls /dev/xvda1 | grep "^$journal_block_nr:" -A 9
