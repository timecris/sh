#!/bin/bash

DIR=/data/

create_file()
{
	for i in `seq 1 500`
	do
		echo "ABCDE" > $DIR/test$i
	done
}

open_file()
{
	for i in `seq $1 500`
	do
		eval "exec $i>$DIR/test$i"
	done
}
