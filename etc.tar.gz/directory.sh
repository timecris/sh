#!/bin/bash

create_directory()
{
	mkdir /home/sunghwan/qemu/linux/tt/tmp$1
	for i in `seq 1 10000`
	do
		mkdir /home/sunghwan/qemu/linux/tt/tmp$1/testtesttesttestabcdefg$i
	done
}

for i in `seq 1 70`
do
	create_directory $i &
done &

