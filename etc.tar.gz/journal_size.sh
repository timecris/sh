#!/bin/bash
BLKDEV=$1
[ -z "$BLKDEV" ] && exit

JOURNAL_TOTAL=$(dumpe2fs $BLKDEV | awk '/Journal length/ {print $3}')
JOURNAL_LENGTH=$(jls $BLKDEV | awk '/Allocated/ { count++; } END { print count }')
PCT=$(echo "scale=2; $JOURNAL_LENGTH/$JOURNAL_TOTAL*100" | bc)

echo JOURNAL_TOTAL:$JOURNAL_TOTAL
echo JOURNAL_LENGTH:$JOURNAL_LENGTH
echo JOURNAL:$PCT
