#!/bin/bash
#file=/home/ubuntu/e2fsprogs/e2fsprogs-1.43.3/e2fsck
function usage {
	cat <<-END >&2
	USAGE: cachectl [filename]
	                 -e evict      # evict page caches related all shared libraries and binary
	                 -t touch      # touch page caches related all shared libraries and binary
END
	exit
}

### process options
while getopts :et opt
do
	case $opt in
	e)	opt_evict=1 ;;
	t)	opt_touch=1 ;;
	h|?)	usage ;;
	esac
done
shift $(( $OPTIND - 1 ))
if (( $# )); then
	file=$1
	shift
fi
(( $# )) && usage

opt=""
(( opt_evict )) && opt="-e"
(( opt_touch )) && opt="-t"

VMTOUCH=/usr/local/bin/vmtouch
FILES=($(ldd $file | tr -d "\t, " | awk -F "[(|=>|)]" '/^lib.{1,}.so.+[0-9]/ {print $3} /ld-linux/ {print $1}'))
for value in "${FILES[@]}"; do 
	vs+="$value "
done
#echo "$VMTOUCH -f $opt $vs"
$VMTOUCH -f $opt $vs

#echo "$VMTOUCH $opt $file"
$VMTOUCH $opt $file
