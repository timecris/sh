#!/bin/bash

DIR=/data/

create_file()
{
	mkdir $DIR/
	for i in `seq 1 500`
	do
		echo "ABCDE" > $DIR/test$i
	done
}

open_file()
{
	for i in `seq 11 1020`
	do
		eval "exec $i>$DIR/tmp9/test$(($i+5089))"
	done
}


for i in `seq 1 10`
do
	create_file $i &
done &



